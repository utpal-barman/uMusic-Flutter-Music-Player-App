#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/utpalbarman/Documents/flutter-sdk/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/utpalbarman/Documents/Flutter Projects/umusic_player"
export "FLUTTER_TARGET=/Users/utpalbarman/Documents/Flutter Projects/umusic_player/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "FLUTTER_FRAMEWORK_DIR=/Users/utpalbarman/Documents/flutter-sdk/flutter/bin/cache/artifacts/engine/ios"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "TRACK_WIDGET_CREATION=true"
