## [0.0.6] - Release

* Future<Iterable<Song>> Bug Fixed.

## [0.0.5] - Release

* run bug fixed due to change off spelling word permission's' in new flutter version.

## [0.0.4] - Release

* Pub Bug Fixed.

## [0.0.3] - Release

* Permission Bug Fixed.

## [0.0.2] - Release

* Example file updated.

## [0.0.1] - Release

* Beautiful Music Player with all basic functionalities.
* Minor Bugs
* Only Android support as of now.
