#import <Flutter/Flutter.h>

@interface MusicFinderPlugin : NSObject<FlutterPlugin>
@end
