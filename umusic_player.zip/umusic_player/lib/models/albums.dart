class AlbumModel {
  String albumName;
  String year;
  bool favorite;
}
