import 'package:umusic_player/models/albums.dart';

List<AlbumModel> mymodellsit = [AlbumModel(), AlbumModel(), AlbumModel()];
